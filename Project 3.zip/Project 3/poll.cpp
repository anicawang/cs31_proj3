#include <iostream>
using namespace std;
#include <string>
#include <cassert>
#include <cctype>

//converts poll data string to all uppercase in order to test with boolean function isValidUppercaseStateCode
string toUpper(string& pdUpper)
{
    //loop throught original string, convert characters to uppercase, store in new string temp
    string temp = "";
    for (int j = 0; j < pdUpper.size(); j++)
    {
        temp += toupper(pdUpper[j]);
    }
    //assign original string with value of new string that is uppercase and return uppercase string
    pdUpper = temp;
    return pdUpper;
}

//return true if the argument is a two-uppercase-letter state code, or false otherwise.
bool isValidUppercaseStateCode(string stateCode)
{
    const string codes =
        "AL.AK.AZ.AR.CA.CO.CT.DE.DC.FL.GA.HI.ID.IL.IN.IA.KS."
        "KY.LA.ME.MD.MA.MI.MN.MO.MS.MT.NE.NV.NH.NJ.NM.NY.NC."
        "ND.OH.OK.OR.PA.RI.SC.SD.TN.TX.UT.VT.VA.WA.WV.WI.WY";
    return (stateCode.size() == 2  &&
            stateCode.find('.') == string::npos  &&  // no '.' in stateCode
            codes.find(stateCode) != string::npos);  // match found
}

//test if poll data string is formatted correctly
//(1 or 2 numbers followed by 2 letter state code followed by 1 letter for party)
bool isSyntacticallyCorrect(string stateForecast)
{
    //poll data string can have 0 state forecasts
    if (stateForecast.size() == 0)
    {
        return true;
    }
    
    //iterate through poll data string to test each individual state forecast
    else
    {
        int i = 0;
        while (i < stateForecast.size())
        {
            //state forecast is of length 4 (1 number 3 letters) if second character is letter
            //state forecast is of length 5 (2 numbers 3 letters) if second character is number
            bool is4 = isalpha(stateForecast[i + 1]);
            
            //if state forecast is of length 4
            if (is4)
            {
                //invalid state forecast if first character is not a digit so return false
                if (!isdigit(stateForecast[i]))
                {
                    return false;
                }
                
                //second and third characters in 4 character state forecast string give state code so create a substring to store 2 letter state code
                string sc = stateForecast.substr(i + 1, 2);
                
                
                //test if 2 digit state code in state forecast is a valid uppercase state code after converting substring to upper case
                if (!isValidUppercaseStateCode(toUpper(sc)))
                {
                    return false;
                }
                
                //if last character in state forecast is not a letter, state forecast is not valid because last character should be letter for party
                if (!isalpha(stateForecast[i + 3]))
                {
                    return false;
                }
                
                //increment index by 4 if 4 digit state forecast is valid
                i += 4;
            }
            
            //if state forecast is of length 5
            else
            {
                //invalid state forecast if first 2 characters are not numbers
                if (!(isdigit(stateForecast[i]) && isdigit(stateForecast[i + 1])))
                {
                    return false;
                }
                
                //third and fourth characters in 5 character state forecast string give state code so create a substring to store 2 letter state code
                string sc = stateForecast.substr(i + 2, 2);
                
                if (!isValidUppercaseStateCode(toUpper(sc)))
                {
                    return false;
                }
                
                //test if 2 digit state code in state forecast is a valid uppercase state code after converting substring to upper case
                if (!isalpha(stateForecast[i + 4]))
                {
                    return false;
                }
                
                //increment index by 5 if 5 digit state forecast is valid
                i += 5;
            }
        }
        //after looping through poll data, if each state forecast is valid, return true, indicating that poll data is syntactically correct
        return true;
    }
}

//records the total number of votes for a specific party given by a poll data string
int tallyVotes (string pollData, char party, int& voteTally)
{
    //if string is not valid poll data string, return 1
    if (!isSyntacticallyCorrect(pollData))
    {
        return 1;
    }
    
    //if parameter party is not a valid letter return 2
    if (!isalpha(party))
    {
        return 2;
    }
    
    //if state forecast predicts zero electoral votes, return 3
    for (int j = 0; j < pollData.size(); )
    {
        //is4 = true when state forecast is length 4, otherwise false
        bool is4 = isalpha(pollData[j + 1]);
        
        //check for 0 in state forecast length 4, return 3 if found
        if (is4)
        {
            if (pollData[j] == '0')
            {
                return 3;
            }
            //increment to test next state forecast
            j += 4;
        }
            
        //check for 0 in state forecast length 5, return 3 if found
        else
        {
            if (pollData[j] == '0' && pollData[j + 1] == '0')
            {
                return 3;
            }
            //increment to test next state forecast
            j += 5;
        }
    }

    //after establishing that poll data string is valid, convert entire poll data string to uppercase
    pollData = toUpper(pollData);
    
    //set vote tally to 0 to keep track of electoral votes
    voteTally = 0;
    
    //empty string for poll data is valid
    if(pollData.size() == 0)
    {
        return 0;
    }

    //loop through poll data string and test if character for party is a letter
    for (int i = 0; i < pollData.size(); )
    {
        //is4 = true when state forecast is length 4, otherwise false
        bool is4 = isalpha(pollData[i + 1]);

        //in 4 character state forecast, party is 4th character, test if it is a character
        if (is4)
        {
            if (pollData[i + 3] == toupper(party))
            {
                //if valid party, convert electoral votes from character in string to integer and add it to vote tally
                voteTally += (pollData[i] - '0');
            }
            //increment to test next state forecast
            i += 4;
        }

        //in 5 character state forecast, party is 5th character, test if it is a character
        else
        {
            if (pollData[i + 4] == toupper(party))
            {
                //if valid party, convert electoral votes from characters in string to integer and add it to vote tally
                int tensdigit = pollData[i] - '0';
                int onesdigit = pollData[i + 1] - '0';
                voteTally += ((tensdigit * 10) + onesdigit);
            }
            //increment to test next state forecast
            i += 5;
        }
    }
    //if valid poll data string, set vote tally to total electoral votes that poll data predicts the party will get and return 0
    return 0;
}

//main method that calls and tests the functions
int main()
{
    //no input or output
    assert(isSyntacticallyCorrect("38TXR55CAD"));
    assert(isSyntacticallyCorrect("38TXR55CAD06nyw5azd"));
    assert(!isSyntacticallyCorrect(" "));
    assert(!isSyntacticallyCorrect("TX5"));
    assert(isSyntacticallyCorrect(""));
    
    int votes = -999; //so we can detect whether tallyVotes sets votes
    assert(tallyVotes("38TXR55CAD6Msr29nYd06UTL", 'd', votes) == 0  &&  votes == 84);
    votes = -999;
    assert(tallyVotes("", 'd', votes) == 0 && votes == 0);
    votes = -999;
    assert(tallyVotes("40ArD60Cad6mSR80DeD07gar", 'D', votes) == 0 && votes == 180);
    votes = -999;
    assert(tallyVotes(" ", '%', votes) == 1 && votes == -999);
    votes = -999;
    assert(tallyVotes("5hIl", 'L', votes) == 0 && votes == 5);
    
    cerr << "All tests succeeded" << endl;
    return 0;
}

